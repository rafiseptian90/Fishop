<footer>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5 about">
                    <h2 class="sub-heading">
                        About Fi-Shop
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati nemo voluptates aperiam amet suscipit. Blanditiis accusamus officiis provident! Neque fugit nostrum sint excepturi facere veniam officia sunt numquam harum molestias.
                    </p>
                </div>
                <div class="col-md-5 socmed text-center">
                    <h2 class="sub-heading">
                        Follow Us
                    </h2>
                    <a href="#" class="link-socmed">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="#" class="link-socmed">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="link-socmed">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="link-socmed">
                        <i class="fab fa-google-plus"></i>
                    </a>
                    <a href="#" class="link-socmed">
                        <i class="fab fa-github"></i>
                    </a>
                </div>
            </div>

            <div class="row copyright">
                <div class="col-10 offset-1">
                    <p>
                        &copy; Rein X RPL 2 - 2019
                    </p>
                </div>
            </div>
        </div>
</footer>