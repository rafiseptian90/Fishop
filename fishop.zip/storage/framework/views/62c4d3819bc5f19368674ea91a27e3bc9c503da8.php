<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Fi-Shop | Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>
    <div class="container auth">
        <div class="row justify-content-center">
            <div class="col-10">
                <div class="card card-login">
                    <div class="card-body login">
                        <div class="row">
                            <div class="col-md-6 col-12 left">
                                <img src="<?php echo e(asset('assets/logo-fi.png')); ?>" alt="Logo Fi-Shop" class="img-brand">
                                <h1 class="name-brand">Fi-Shop</h1>
                                <p class="description">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit Fuga nostrum accusantium, doloremque.
                                </p>
                            </div>
                            <div class="col-md-6 col-12 right">
                                <h1 class="login-title">
                                    Login
                                </h1>
                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row">
                                        <div class="col-md-8">
                                            <label for="email"><?php echo e(__('E-mail')); ?></label>
                                            <input id="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="email" placeholder="example@example.com">
                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-md-8">
                                            <label for="email"><?php echo e(__('Password')); ?></label>
                                            <input id="email" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="password" name="password" placeholder="*******">
                                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-md-8">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                <label class="form-check-label" for="remember">
                                                    <?php echo e(__('Remember Me')); ?>

                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top: -16px; margin-bottom: 16px;">
                                        <?php if(Route::has('password.request')): ?>
                                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                                <?php echo e(__('Forgot Your Password?')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row" style="margin-top: -16px; margin-bottom: 16px;">
                                        <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                                            <?php echo e(__('Sign Up')); ?>

                                        </a>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5 col-sm-5 col-12">
                                            <button class="btn-auth" type="submit">
                                                Login
                                            </button>
                                        </div>
                                    </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\laravel_project\fishop\resources\views/auth/login.blade.php ENDPATH**/ ?>