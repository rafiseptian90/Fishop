<?php $__env->startSection('content'); ?>
     <section id="carts">
          
          <?php if(Cookie::get('cart')): ?>
               <div class="container">
                    <div class="row cart-header mt-4">
                         <div class="col-md-12">
                              <h1 class="cart-title">
                                   <i class="fas fa-shopping-cart"></i> Cart
                              </h1>
                         </div>
                    </div>
               </div>

          <div class="list-cart">
               <div class="container">
                    <div class="row">
                         <div class="col-md-9">
                              <div class="row">
                                   <div class="col-md-12">
                                        <h2 class="cart-text">
                                             Your Selection
                                        </h2>
                                   </div>
                              </div>
                              <div class="row cart-table">
                                   <div class="col-md-12">
                                        <table class="table table-hover table-responsive">
                                             <thead>
                                                  <th>No</th>
                                                  <th>Gambar</th>
                                                  <th style="min-width:18%">Nama Software</th>
                                                  <th>Deksripsi</th>
                                                  <th>Harga</th>
                                                  <th>Hapus</th>
                                             </thead>

                                             <tbody>
                                                  <?php $subtotal = 0; $no = 1 ?>
                                                  <?php $__currentLoopData = json_decode(Cookie::get('cart')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php $subtotal+=\App\Product::find($product)->price; ?>
                                                       <tr>
                                                            <td><?php echo e($no++); ?></td>
                                                            <td>
                                                                 <img src="<?php echo e(asset('storage/' . \App\Product::find($product)->photo)); ?>" alt="" width="100px" height="100px">
                                                            </td>
                                                            <td><?php echo e(\App\Product::find($product)->name); ?></td>
                                                            <td><?php echo \App\Product::find($product)->description; ?></td>
                                                            <td>Rp.<?php echo e(number_format(\App\Product::find($product)->price)); ?></td>
                                                            <td>
                                                                 <a href="<?php echo e(route('cart.cancel')); ?>" class="remove-cart" data-id="<?php echo e($id); ?>">
                                                                      <i class="fas fa-times"></i>
                                                                 </a>
                                                            </td>
                                                       </tr>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </tbody>
                                        </table>
                                   </div>
                              </div>
                         </div>
                         
                         <div class="col-md-3 col-sm-12">
                              <div class="row">
                                   <div class="col-12">
                                        <h2 class="cart-text">
                                             Cart Total
                                        </h2>
                                   </div>
                              </div>
                              <div class="row">
                                   <div class="col-12">
                                        <table class="table table-hover table-responsive" style="width: 100%;">
                                             <tr>
                                                  <td class="cart-total-title">Total :</td>
                                                  <td class="cart-total-body">Rp.<?php echo e(number_format($subtotal)); ?></td>
                                             </tr>
                                             
                                        </table>
                                        
                                        <form method="post" action="<?php echo e(route('purchase.store')); ?>" enctype="multipart/form-data">
                                             <?php echo e(csrf_field()); ?>

                                             <div class="form-group">
                                                  <label for="payment_id">Pilih Pembayaran</label>
                                                  <select id="payment_id" class="form-control" name="payment_id">
                                                       <?php $__currentLoopData = \App\Payment::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($payment->id); ?>"><?php echo e($payment->name); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </select>
                                             </div>
                                             <div class="form-group">
                                                  <label for="proof">Bukti Pembayaran</label>
                                                  <input id="proof" class="form-control-file <?php if ($errors->has('proof')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('proof'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="file" name="proof">
                                                  <?php if ($errors->has('proof')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('proof'); ?>
                                                       <span class="invalid-feedback" role="alert">
                                                            <div class="alert alert-danger">
                                                                 <strong><?php echo e($message); ?></strong>
                                                            </div>
                                                       </span>
                                                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                             </div>

                                             <button type="submit" class="btn-checkout">
                                                  <i class="far fa-money-bill-alt"></i> Checkout
                                             </button>
                                        </form>

                                        <br>

                                        <a href="#" class="continue-shop">
                                             Continue Shopping
                                        </a>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
          <?php else: ?>
               <div class="no-cart">
                    <i class="far fa-frown fa-5x mb-3"></i>
                    <h3>
                         You not have a cart
                    </h3>
               </div>
          <?php endif; ?>
     </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\fishop\resources\views/sites/cart.blade.php ENDPATH**/ ?>