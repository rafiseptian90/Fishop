<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row brand">
        <div class="col-12 text-center">
            <img src="<?php echo e(asset('assets/logo-fi.png')); ?>" alt="">
        </div>
    </div>
    <div class="row filtering mb-4" style="margin-top: 8%;">
        <div class="col-md-12 col-12">
            <div class="row">
                <form action="<?php echo e(route('product')); ?>" method="get" class="form-inline" style="padding: 0;">
                    <div class="col-md-10 col-10">
                        <input type="text" name="search" id="search" class="form-control"
                            placeholder="Search Product or Category" style="width:100%">
                    </div>
                    <div class="col-md-2 col-2">
                        <button class="btn btn-primary btn-search">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row list-products">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="row img-product">
                        <div class="col-12">
                            <img src="<?php echo e(asset('storage/' . $product->photo)); ?>" alt="<?php echo e($product->name); ?>">
                        </div>
                    </div>
                    <div class="row desc">
                        <div class="col-md-6 col-6">
                            <h3 class="name-product"><?php echo e($product->name); ?></h3>
                            <span class="category"><?php echo e($product->category->name); ?></span>
                        </div>
                        <div class="col-md-6 col-6 text-right">
                            <p class="price">Rp.<?php echo e(number_format($product->price)); ?></p> 
                            <i class="fas fa-star"></i> <?php echo e($product->rating); ?>

                            
                        </div>
                    </div>

                    <div class="row" style="margin-top:10px;">
                        <div class="col-12">
                            <a href="<?php echo e(route('cart.store')); ?>" class="btn btn-primary" id="buy"
                                data-id="<?php echo e($product->id); ?>">
                                <i class="fas fa-shopping-cart"></i> Buy
                            </a>

                            <a href="<?php echo e(route('view.product', $product->id)); ?>" class="btn btn-secondary" id="view"
                                style="margin-left:3px;">
                                <i class="fas fa-eye"></i> View
                            </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\fishop\resources\views/sites/products.blade.php ENDPATH**/ ?>